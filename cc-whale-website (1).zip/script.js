// ==================== 全局变量 ====================
let cartCount = 0;
let wishlistCount = 0;
const cartCountElement = document.querySelector('.cart-count');

// ==================== DOM 加载完成 ====================
document.addEventListener('DOMContentLoaded', function() {
    initializeMobileMenu();
    initializeProductInteractions();
    initializeNewsletterForm();
    initializeBackToTop();
    initializeSmoothScroll();
    initializeHoverEffects();
    initializeBrandModal();
    initializeBrandBanner();
});

// ==================== 移动端菜单 ====================
function initializeMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navMenu = document.querySelector('.nav-menu');

    if (mobileMenuBtn && navMenu) {
        mobileMenuBtn.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            this.classList.toggle('active');
        });

        // 点击菜单外部关闭菜单
        document.addEventListener('click', function(event) {
            const isClickInside = navMenu.contains(event.target) || 
                                mobileMenuBtn.contains(event.target);
            
            if (!isClickInside && navMenu.classList.contains('active')) {
                navMenu.classList.remove('active');
                mobileMenuBtn.classList.remove('active');
            }
        });

        // 点击菜单项后关闭菜单
        const menuLinks = navMenu.querySelectorAll('a');
        menuLinks.forEach(link => {
            link.addEventListener('click', function() {
                navMenu.classList.remove('active');
                mobileMenuBtn.classList.remove('active');
            });
        });
    }
}

// ==================== 产品交互 ====================
function initializeProductInteractions() {
    // 购物车按钮
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const productCard = this.closest('.product-card');
            const productName = productCard.querySelector('h3').textContent;
            
            addToCart(productName);
            showNotification('已将 "' + productName + '" 加入购物车');
            
            // 按钮动画效果
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    });

    // 收藏按钮
    const wishlistButtons = document.querySelectorAll('.wishlist-toggle');
    wishlistButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            this.classList.toggle('active');
            const isActive = this.classList.contains('active');
            
            if (isActive) {
                this.innerHTML = `
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                    </svg>
                `;
                wishlistCount++;
                showNotification('已添加到收藏');
            } else {
                this.innerHTML = `
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                    </svg>
                `;
                wishlistCount--;
                showNotification('已取消收藏');
            }
        });
    });

    // 产品卡片悬停效果增强
    const productCards = document.querySelectorAll('.product-card');
    productCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            const image = this.querySelector('.product-image img');
            if (image) {
                image.style.transition = 'transform 0.6s ease';
            }
        });
    });
}

// ==================== 购物车功能 ====================
function addToCart(productName) {
    cartCount++;
    updateCartCount();
    
    // 可以在这里添加localStorage存储购物车数据
    // localStorage.setItem('cart', JSON.stringify(cartData));
}

function updateCartCount() {
    if (cartCountElement) {
        cartCountElement.textContent = cartCount;
        
        // 添加动画效果
        cartCountElement.style.transform = 'scale(1.2)';
        setTimeout(() => {
            cartCountElement.style.transform = 'scale(1)';
        }, 200);
    }
}

// ==================== 通知提示 ====================
function showNotification(message) {
    // 移除已存在的通知
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }

    // 创建新的通知
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background-color: #000;
        color: #fff;
        padding: 15px 25px;
        border-radius: 4px;
        font-size: 14px;
        font-weight: 500;
        z-index: 10000;
        animation: slideIn 0.3s ease;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    `;

    document.body.appendChild(notification);

    // 3秒后自动移除
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// 添加动画样式
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// ==================== Newsletter 表单 ====================
function initializeNewsletterForm() {
    const newsletterForm = document.querySelector('.newsletter-form');
    
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const emailInput = this.querySelector('input[type="email"]');
            const email = emailInput.value.trim();
            
            if (validateEmail(email)) {
                showNotification('订阅成功！感谢您的关注');
                emailInput.value = '';
            } else {
                showNotification('请输入有效的邮箱地址');
            }
        });
    }
}

// ==================== 返回顶部功能 ====================
function initializeBackToTop() {
    const backToTopBtn = document.getElementById('backToTop');
    
    if (backToTopBtn) {
        // 滚动时显示/隐藏按钮
        window.addEventListener('scroll', function() {
            if (window.scrollY > 500) {
                backToTopBtn.classList.add('visible');
            } else {
                backToTopBtn.classList.remove('visible');
            }
        });

        // 点击返回顶部
        backToTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}

// ==================== 平滑滚动 ====================
function initializeSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // 忽略只有 # 的链接
            if (href === '#') return;
            
            const targetElement = document.querySelector(href);
            
            if (targetElement) {
                e.preventDefault();
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// ==================== 悬停效果 ====================
function initializeHoverEffects() {
    // 导航链接激活状态
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-menu a[href^="#"]');
    
    if (sections.length > 0 && navLinks.length > 0) {
        window.addEventListener('scroll', function() {
            let current = '';
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                
                if (pageYOffset >= sectionTop - 200) {
                    current = section.getAttribute('id');
                }
            });

            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === '#' + current) {
                    link.classList.add('active');
                }
            });
        });
    }

    // 产品图片懒加载效果
    const productImages = document.querySelectorAll('.product-image img');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.style.opacity = '0';
                img.style.transition = 'opacity 0.5s ease';
                
                setTimeout(() => {
                    img.style.opacity = '1';
                }, 100);
                
                observer.unobserve(img);
            }
        });
    }, {
        threshold: 0.1
    });

    productImages.forEach(img => {
        imageObserver.observe(img);
    });
}

// ==================== 工具函数 ====================
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ==================== 页面加载动画 ====================
window.addEventListener('load', function() {
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.5s ease';
    
    setTimeout(() => {
        document.body.style.opacity = '1';
    }, 100);
});

// ==================== 键盘导航 ====================
document.addEventListener('keydown', function(e) {
    // ESC 键关闭移动菜单和弹窗
    if (e.key === 'Escape') {
        const navMenu = document.querySelector('.nav-menu');
        const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
        const brandModal = document.getElementById('brandModal');
        
        if (navMenu && navMenu.classList.contains('active')) {
            navMenu.classList.remove('active');
            if (mobileMenuBtn) {
                mobileMenuBtn.classList.remove('active');
            }
        }
        
        if (brandModal && brandModal.classList.contains('active')) {
            brandModal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }
});

// ==================== 品牌介绍弹窗 ====================
function initializeBrandModal() {
    const brandLogo = document.getElementById('brandLogo');
    const brandModal = document.getElementById('brandModal');
    const modalOverlay = document.getElementById('modalOverlay');
    const modalClose = document.getElementById('modalClose');
    const modalOk = document.getElementById('modalOk');

    console.log('品牌弹窗初始化:', { brandLogo: !!brandLogo, brandModal: !!brandModal });

    if (brandLogo && brandModal) {
        // 移除可能存在的旧事件监听器
        const newLogo = brandLogo.cloneNode(true);
        brandLogo.parentNode.replaceChild(newLogo, brandLogo);
        
        // 为新的Logo元素添加点击事件
        newLogo.addEventListener('click', function(e) {
            console.log('Logo被点击了！');
            e.preventDefault();
            e.stopPropagation();
            brandModal.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
        
        console.log('品牌Logo点击事件已绑定');
    }

    // 点击遮罩层关闭弹窗
    if (modalOverlay) {
        modalOverlay.addEventListener('click', function() {
            brandModal.classList.remove('active');
            document.body.style.overflow = '';
        });
    }

    // 点击关闭按钮
    if (modalClose) {
        modalClose.addEventListener('click', function() {
            brandModal.classList.remove('active');
            document.body.style.overflow = '';
        });
    }

    // 点击确定按钮
    if (modalOk) {
        modalOk.addEventListener('click', function() {
            brandModal.classList.remove('active');
            document.body.style.overflow = '';
            showNotification('感谢您的关注！');
        });
    }
}

// ==================== 品牌横幅 ====================
function initializeBrandBanner() {
    const bannerClose = document.getElementById('bannerClose');
    const brandBanner = document.querySelector('.brand-banner');

    if (bannerClose && brandBanner) {
        bannerClose.addEventListener('click', function() {
            brandBanner.classList.add('hidden');
            // 保存到localStorage，用户下次访问不再显示
            localStorage.setItem('brandBannerHidden', 'true');
        });
    }

    // 检查是否已经关闭过
    if (localStorage.getItem('brandBannerHidden') === 'true' && brandBanner) {
        brandBanner.classList.add('hidden');
    }
}

console.log('CC的鲸鱼网站已成功加载！');

// ==================== 搜索功能模拟 ====================
const searchBtn = document.querySelector('.search-btn');
if (searchBtn) {
    searchBtn.addEventListener('click', function() {
        showNotification('搜索功能开发中...');
    });
}

// ==================== 购物车功能模拟 ====================
const cartBtn = document.querySelector('.cart-btn');
if (cartBtn) {
    cartBtn.addEventListener('click', function() {
        if (cartCount > 0) {
            showNotification(`购物车中有 ${cartCount} 件商品`);
        } else {
            showNotification('购物车是空的');
        }
    });
}

// ==================== 收藏功能模拟 ====================
const wishlistBtn = document.querySelector('.wishlist-btn');
if (wishlistBtn) {
    wishlistBtn.addEventListener('click', function() {
        if (wishlistCount > 0) {
            showNotification(`收藏夹中有 ${wishlistCount} 件商品`);
        } else {
            showNotification('收藏夹是空的');
        }
    });
}

console.log('CC的鲸鱼网站已成功加载！');