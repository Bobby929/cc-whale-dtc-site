# CC的鲸鱼 - DTC官网

专为现代女性打造的高品质女装品牌官网，采用现代化设计理念，优雅与舒适的完美融合。

## 🌟 项目特点

- **响应式设计**: 完美适配桌面、平板、手机各种设备
- **现代化UI**: 采用渐变色、玻璃拟态等现代设计元素
- **流畅交互**: 产品悬停效果、动画过渡、平滑滚动
- **性能优化**: 图片懒加载、代码压缩、缓存策略
- **SEO优化**: 完善的meta标签、语义化HTML
- **用户体验**: 移动端友好、键盘导航、通知提示

## 🚀 快速部署到 Cloudflare Pages

### 方法一：通过 Git 仓库部署

1. **推送到 GitHub/GitLab**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin <你的仓库地址>
   git push -u origin main
   ```

2. **在 Cloudflare Pages 部署**
   - 登录 [Cloudflare Dashboard](https://dash.cloudflare.com/)
   - 进入 "Pages" → "Create a project"
   - 选择 "Connect to Git"
   - 授权并选择你的仓库
   - 构建设置：
     - **Framework preset**: None
     - **Build command**: 留空
     - **Build output directory**: `/` (根目录)
   - 点击 "Save and Deploy"

### 方法二：直接上传部署

1. **安装 Wrangler CLI**
   ```bash
   npm install -g wrangler
   ```

2. **登录 Cloudflare**
   ```bash
   wrangler login
   ```

3. **部署项目**
   ```bash
   wrangler pages deploy . --project-name=cc-whale-website
   ```

## 📁 项目结构

```
.
├── index.html          # 主页面文件
├── styles.css          # 样式表
├── script.js           # JavaScript交互逻辑
├── image.png           # 品牌图片
├── wrangler.toml       # Cloudflare配置文件
└── README.md           # 项目说明文档
```

## 🎨 主要功能

- 品牌故事展示
- 产品分类导航
- 新品推荐
- 热销榜单
- 购物车功能（前端模拟）
- 收藏夹功能
- Newsletter订阅
- 移动端适配
- 平滑滚动
- 返回顶部

## ⚙️ 自定义配置

### 修改品牌信息
编辑 `index.html` 中的以下内容：
- 品牌名称：`CC的鲸鱼`
- 品牌故事
- 联系方式
- 社交媒体链接

### 更换产品图片
在 `index.html` 中找到 `<img>` 标签，替换 `src` 属性中的图片URL。

### 修改配色方案
编辑 `styles.css` 中的 `:root` 变量：
```css
:root {
    --color-black: #000000;
    --color-accent: #e74c3c;
    /* 更多颜色变量... */
}
```

## 🌐 自定义域名

1. 在 Cloudflare Pages 项目设置中点击 "Custom domains"
2. 添加你的域名（如：`www.yourdomain.com`）
3. 按照提示在域名DNS中添加CNAME记录
4. 等待SSL证书自动颁发

## 📊 性能监控

部署后，Cloudflare Pages 自动提供：
- 全球CDN加速
- SSL/TLS加密
- DDoS防护
- 自动HTTPS重定向
- 图片优化

## 🔧 开发建议

### 本地开发
1. 使用本地服务器预览：
   ```bash
   # 使用 Python
   python -m http.server 8000

   # 使用 Node.js
   npx serve .
   ```

2. 访问 `http://localhost:8000`

### 生产优化建议
- 压缩图片（使用TinyPNG或Squoosh）
- 启用Brotli压缩（Cloudflare自动处理）
- 实施图片懒加载（已集成）
- 使用WebP格式图片

## 📝 注意事项

- 所有外部图片使用Unsplash CDN，生产环境建议替换为自己的图片服务器
- 购物车、收藏夹功能为前端模拟，实际使用需要后端API支持
- Newsletter表单需要对接邮件服务API

## 🆘 常见问题

**Q: 部署后页面样式错乱？**
A: 确保所有文件都已上传，特别是 `styles.css` 文件。

**Q: 如何更新网站？**
A: 推送新代码到Git仓库，Cloudflare会自动重新部署。

**Q: 如何查看访问统计？**
A: 在 Cloudflare Dashboard 中查看 Analytics。

## 📞 技术支持

如有问题，请访问：
- [Cloudflare Pages 文档](https://developers.cloudflare.com/pages/)
- [Wrangler CLI 文档](https://developers.cloudflare.com/workers/wrangler/)

## 📄 许可证

© 2026 CC的鲸鱼. 保留所有权利.
